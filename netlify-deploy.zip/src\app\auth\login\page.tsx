'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

type LoginType = 'author' | 'reader'

// 读者授权密码 - 开发者预设
const READER_AUTH_PASSWORD = 'novelhub2025'

export default function LoginPage() {
  const router = useRouter()
  const [loginType, setLoginType] = useState<LoginType>('reader')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [authCode, setAuthCode] = useState('')
  const [username, setUsername] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    try {
      const supabase = createClient()

      if (loginType === 'author') {
        // 作者登录：邮箱 + 密码
        const { error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        })
        if (error) throw error
      } else {
        // 读者登录：验证授权密码
        const trimmedUsername = username.trim()
        const trimmedAuthCode = authCode.trim()

        if (!trimmedUsername) {
          throw new Error('请输入用户名')
        }
        if (trimmedAuthCode !== READER_AUTH_PASSWORD) {
          throw new Error('授权密码错误，请联系开发者获取访问权限')
        }

        // 读者使用固定邮箱格式登录
        const readerEmail = `reader_${trimmedUsername}@novelhub.local`
        
        // 先尝试登录，如果不存在则自动注册
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: readerEmail,
          password: trimmedAuthCode,
        })

        if (signInError) {
          // 用户不存在，自动注册
          const { error: signUpError } = await supabase.auth.signUp({
            email: readerEmail,
            password: trimmedAuthCode,
            options: {
              data: {
                username: trimmedUsername,
                display_name: trimmedUsername,
                role: 'reader',
              },
            },
          })
          if (signUpError) throw signUpError
        }
      }

      router.push('/')
      router.refresh()
    } catch (err) {
      setError(err instanceof Error ? err.message : '登录失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50">
      <div className="w-full max-w-md mx-4">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">📚 欢迎回来</h1>
            <p className="text-gray-500">登录您的 Novel Hub 账户</p>
          </div>

          {/* 登录类型选择 */}
          <div className="flex gap-2 mb-6 p-1 bg-gray-100 rounded-xl">
            <button
              type="button"
              onClick={() => setLoginType('reader')}
              className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                loginType === 'reader'
                  ? 'bg-white text-amber-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              👤 读者登录
            </button>
            <button
              type="button"
              onClick={() => setLoginType('author')}
              className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                loginType === 'author'
                  ? 'bg-white text-amber-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              ✍️ 作者登录
            </button>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            {loginType === 'author' ? (
              // 作者登录表单
              <>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1.5">
                    邮箱地址
                  </label>
                  <input
                    id="email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition-all text-gray-800 bg-gray-50 focus:bg-white"
                    placeholder="your@email.com"
                  />
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1.5">
                    密码
                  </label>
                  <input
                    id="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition-all text-gray-800 bg-gray-50 focus:bg-white"
                    placeholder="••••••••"
                  />
                </div>
              </>
            ) : (
              // 读者登录表单
              <>
                <div>
                  <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1.5">
                    用户名
                  </label>
                  <input
                    id="username"
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition-all text-gray-800 bg-gray-50 focus:bg-white"
                    placeholder="输入您的用户名"
                  />
                </div>

                <div>
                  <label htmlFor="authCode" className="block text-sm font-medium text-gray-700 mb-1.5">
                    授权密码
                  </label>
                  <input
                    id="authCode"
                    type="password"
                    required
                    value={authCode}
                    onChange={(e) => setAuthCode(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition-all text-gray-800 bg-gray-50 focus:bg-white"
                    placeholder="请输入开发者提供的授权密码"
                  />
                  <p className="mt-1.5 text-xs text-gray-500">
                    授权密码由开发者提供，用于验证读者身份
                  </p>
                </div>
              </>
            )}

            {error && (
              <div className="bg-red-50 text-red-600 px-4 py-3 rounded-xl text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-semibold rounded-xl hover:from-amber-600 hover:to-orange-600 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-amber-200"
            >
              {loading ? '登录中...' : '登 录'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-500 text-sm">
              {loginType === 'author' ? (
                <>
                  还没有作者账户？{' '}
                  <Link href="/auth/register" className="text-amber-600 hover:text-amber-700 font-medium">
                    注册作者账户
                  </Link>
                </>
              ) : (
                <>
                  需要获取授权密码？{' '}
                  <span className="text-gray-400">请联系开发者</span>
                </>
              )}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
