import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'

export const dynamic = 'force-dynamic'

export default async function AdminDashboard() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">请先登录</p>
      </div>
    )
  }

  let novelCount = 0
  let chapterCount = 0
  let recentNovels: any[] = []

  try {
    const [novelCountResult, novelsResult] = await Promise.all([
      supabase
        .from('novels')
        .select('*', { count: 'exact', head: true })
        .eq('author_id', user.id),
      supabase
        .from('novels')
        .select('*, profiles(display_name)')
        .eq('author_id', user.id)
        .order('updated_at', { ascending: false })
        .limit(5),
    ])

    novelCount = novelCountResult.count || 0
    recentNovels = novelsResult.data || []

    // Get chapter count using novel IDs
    const novelIds = recentNovels.map(n => n.id)
    if (novelIds.length > 0) {
      const chapterCountResult = await supabase
        .from('chapters')
        .select('novel_id', { count: 'exact', head: true })
        .in('novel_id', novelIds)
      chapterCount = chapterCountResult.count || 0
    }
  } catch (error) {
    console.error('Failed to load admin data:', error)
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">📊 管理仪表盘</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="text-3xl font-bold text-amber-600">{novelCount}</div>
          <div className="text-gray-500 mt-1">小说总数</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="text-3xl font-bold text-orange-600">{chapterCount}</div>
          <div className="text-gray-500 mt-1">章节总数</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="text-3xl font-bold text-green-600">
            {recentNovels?.filter(n => n.is_published).length || 0}
          </div>
          <div className="text-gray-500 mt-1">已发布</div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">最近更新</h2>
          <Link href="/admin/novels" className="text-amber-600 hover:text-amber-700 text-sm font-medium">
            查看全部 →
          </Link>
        </div>
        {recentNovels && recentNovels.length > 0 ? (
          <div className="divide-y divide-gray-50">
            {recentNovels.map((novel) => (
              <div key={novel.id} className="px-6 py-4 flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-gray-800">{novel.title}</h3>
                  <p className="text-sm text-gray-500 mt-0.5">
                    {novel.status === 'ongoing' ? '连载中' : novel.status === 'completed' ? '已完结' : '暂停中'}
                    {' · '}
                    {new Date(novel.updated_at).toLocaleDateString('zh-CN')}
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-2.5 py-1 text-xs rounded-full font-medium ${
                    novel.is_published
                      ? 'bg-green-100 text-green-700'
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    {novel.is_published ? '已发布' : '草稿'}
                  </span>
                  <Link
                    href={`/admin/novels/${novel.id}/stats`}
                    className="text-blue-600 hover:text-blue-700 text-sm"
                    title="数据统计"
                  >
                    📊
                  </Link>
                  <Link
                    href={`/admin/novels/${novel.id}`}
                    className="text-amber-600 hover:text-amber-700 text-sm"
                  >
                    编辑
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="px-6 py-12 text-center text-gray-400">
            <p>还没有小说，点击下方按钮开始创作吧！</p>
          </div>
        )}
      </div>

      <div className="mt-6">
        <Link
          href="/admin/novels/new"
          className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-semibold rounded-xl hover:from-amber-600 hover:to-orange-600 transition-all shadow-lg shadow-amber-200"
        >
          ✏️ 新建小说
        </Link>
      </div>
    </div>
  )
}
